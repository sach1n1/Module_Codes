var mqtt=require('mqtt');
const puppeteer = require('puppeteer');
var topic="Fiware/Test1";
var topic1="Fiware/Test2";
var status="close";

options={
    clientId:"mqttjs01",
    username:"openhabian",
    password:"openhabian",
    clean:true};

var client  = mqtt.connect("mqtt://192.168.20.52",options);
console.log("connected flag" + client.connected);

client.on('message',function(topic, message, packet){
    console.log(topic);
    if(topic=="Fiware/Test1")
    {
        console.log("topic1 " + topic);

        (async () => {

            status="open";
            const browser = await puppeteer.launch({"executablePath":"/usr/bin/chromium-browser","headless":false,args: ['--start-fullscreen'],defaultViewport: null});
            const page = await browser.newPage();
            //await page.setViewport({ width: 1920, height: 1080 });
            await page.goto('https://www.google.com/');
            setTimeout(() => { browser.close(); }, 10000);
        })();
    }

    if(topic=="Fiware/Test2")
    {
        console.log("topic2 " + topic);

        (async () => {

            status="open";
            const browser = await puppeteer.launch({"executablePath":"/usr/bin/chromium-browser","headless":false,args: ['--start-fullscreen'],defaultViewport: null});
            const page = await browser.newPage();
            //await page.setViewport({ width: 1920, height: 1080 });
            await page.goto('https://www.gmail.com/');
            setTimeout(() => { browser.close(); }, 3000);
        })();
    }

    if(topic=="Fiware/Test3")
    {

        (async () => {

            status="open";
            const browser = await puppeteer.launch({"executablePath":"/usr/bin/chromium-browser","headless":false,args: ['--start-fullscreen'],defaultViewport: null});
            const page = await browser.newPage();
            //await page.setViewport({ width: 1920, height: 1080 });
            await page.goto('https://www.google.com/');
            setTimeout(() => { browser.close(); }, 3000);
        })();
    }
});


client.on("connect",function(){	
    console.log("connected  "+ client.connected);    
})
client.subscribe(topic,{qos:0});
client.subscribe(topic1,{qos:0});
