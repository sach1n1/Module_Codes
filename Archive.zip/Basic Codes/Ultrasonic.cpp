// Using this code we are connecting the Wio Link board to an Ultrasonic Sensor and sending
// sending the values obtained from the ultasonic sensor to an MQTT Broker
// Connect the ultrasonic sensor to digital port D2 of Wio Link Board
// Code taken from Grove Ultrasonic Ranger wiki (modified for MQTT support)
// https://wiki.seeedstudio.com/Grove-Ultrasonic_Ranger/

#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <PubSubClient.h>
#include "Ultrasonic.h"

Ultrasonic ultrasonic(13);
//Replace with your WiFi Name, Password and MQTT Broker IP
const char* ssid = "SSID";
const char* password =  "PASS";
#define mqtt_server "IP"
WiFiClient espClient;
PubSubClient client(espClient);

void reconnect() {
  while (!client.connected()) {
    Serial.print("Attempting MQTT connection...");
    // change ("ESP8266Client")) client name according to use case (multiple clients having same name will crash the MQTT broker)
    if (client.connect("ESP8266Client")) {
      Serial.println("connected");
    } else {
      Serial.print("failed, rc=");
      Serial.print(client.state());
      Serial.println(" try again in 5 seconds");
      delay(5000);
    }
  }
}

void setup()
{
    //pin 15 made high to make ports of Wio Link board functional
    pinMode(15,OUTPUT);
    digitalWrite(15,1);
    WiFi.begin(ssid, password);
    Serial.print("Connecting");
    while (WiFi.status() != WL_CONNECTED)
    {
      delay(500);
      Serial.print(".");
    }
    Serial.println();
    //Dsiplay's IP addres of the connected device
    Serial.print("Connected, IP address: ");
    Serial.println(WiFi.localIP());
    client.setServer(mqtt_server, 1883);
    Serial.begin(9600);
}

void loop()
{
    long RangeInInches;
      if (!client.connected()) {
        reconnect();
     }
    client.loop();
    Serial.println();
    //Take readings every 1 second
    Serial.println("The distance to obstacles in front is: ");
    RangeInInches = ultrasonic.MeasureInInches();
    Serial.print(RangeInInches); //0~157 inches
    Serial.println(" inch");
    //Publish the value to the MQTT broker, can be observed using MQTT.fx client.
    client.publish("test/out_topic",String(RangeInInches).c_str(),true);
    //Uncomment if you want the measurement in centimeters
    //RangeInCentimeters = ultrasonic.MeasureInCentimeters(); 
    //Serial.print(RangeInCentimeters);//0~400cm
    //Serial.println(" cm");
    delay(1000);
}