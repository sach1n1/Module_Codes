//This code is programmed to run a NodeMCU with Neopixel Ring
//Input on the Habpanel in the form of the colour reflects on the Colour ring
//The DI (Data in) of the LED ring connects to the pin D$ of the NodeMCU

#include <Adafruit_NeoPixel.h>
#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <PubSubClient.h>

const char* ssid = "FIWARE";
const char* password = "!FIWARE!on!air!";

#define mqtt_server "192.168.20.52"
WiFiClient espClient;
PubSubClient client(espClient);


void reconnect() {
  while (!client.connected()) {
    Serial.print("Attempting MQTT connection...");
    if (client.connect("ColourWheel","openhabian","openhabian")) {
      Serial.println("connected");
    }else{
      Serial.print("failed, rc=");
      Serial.print(client.state());
    }
  }
}

#define PIN D4 //NODEMCU
Adafruit_NeoPixel strip = Adafruit_NeoPixel(12, PIN, NEO_GRB + NEO_KHZ800);

// IMPORTANT: To reduce NeoPixel burnout risk, add 1000 uF capacitor across
// pixel power leads, add 300 - 500 Ohm resistor on first pixel's data input
// and minimize distance between Arduino and first pixel.  Avoid connecting
// on a live circuit...if you must, connect GND first.

uint32_t Wheel(byte WheelPos) {
  WheelPos = 255 - WheelPos;
  if(WheelPos < 85) {
    return strip.Color(255 - WheelPos * 3, 0, WheelPos * 3);
  }
  if(WheelPos < 170) {
    WheelPos -= 85;
    return strip.Color(0, WheelPos * 3, 255 - WheelPos * 3);
  }
  WheelPos -= 170;
  return strip.Color(WheelPos * 3, 255 - WheelPos * 3, 0);
}

void colorWipe(uint32_t c, uint8_t wait) {
  for(uint16_t i=0; i<strip.numPixels(); i++) {
    strip.setPixelColor(i, c);
    strip.show();
    delay(wait);
  }
}

void callback(char* topic, byte* payload, unsigned int length) {

  int i,rgb[3],k=0,p=0;
  char pay[15],temp[3];
  for (i = 0; i < length; i++) {
    pay[i]=(char)payload[i];
  }
  pay[i]='\0';
  for(i=0;pay[i]!='\0';i++)
  {
    if(pay[i]!=',')
    {  temp[k]=pay[i];k++;}
    else
    {
      temp[k]='\0';
      k=0;
      rgb[p]=atoi(temp);
      p++;
    }
  }
  temp[k]='\0';
  rgb[p]=atoi(temp);
  colorWipe(strip.Color(rgb[0],rgb[1],rgb[2]), 50);
}

void setup()
{
  Serial.begin(9600);

  WiFi.begin(ssid, password);
  Serial.print("Connecting");
  while (WiFi.status() != WL_CONNECTED)
  {
    delay(500);
  }
  client.setServer(mqtt_server, 1883);
  client.setCallback(callback);
  strip.begin();
  strip.show(); 
}

void loop()
{
  if (!client.connected()) {
    reconnect();
  }
  client.loop();
  client.subscribe("Fiware/Farm/Colour");
  //delay(1000);
}