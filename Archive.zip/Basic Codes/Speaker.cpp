// Using this code we are connecting the Wio Link board to the Grove speaker and it is connected to a MQTT broker
// The speaker plays bass notes when it receives amessage from the subscribed MQTT topic
// Connect the speaker to digital port D2 of Wio Link Board
// Code taken from Grove Speaker wiki (modified for MQTT support)
// https://wiki.seeedstudio.com/Grove-Speaker/

#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <PubSubClient.h>
#include <Wire.h>
#include <SeeedOLED.h>


//Speaker defined on port 2
#define SPEAKER 2

//Bass notes defined according to frequency
int BassTab[]={1911,1702,1516,1431,1275,1136,1012};//bass 1~7

//Replace with your WiFi Name, Password and MQTT Broker IP
const char* ssid = "SSID";
const char* password =  "PASS";
#define mqtt_server "IP"
WiFiClient espClient;
PubSubClient client(espClient);

void reconnect() {
  while (!client.connected()) {
    Serial.print("Attempting MQTT connection...");
    // change ("ESP8266Client")) client name according to use case (multiple clients having same name will crash the MQTT broker)
    if (client.connect("ESP8266Client")) {
      Serial.println("connected");
    } else {
      Serial.print("failed, rc=");
      Serial.print(client.state());
      Serial.println(" try again in 5 seconds");
      delay(5000);
    }
  }
}

//Initializing Speaker on Digital Port 2 of Wio Link Board
void pinInit()
{
    pinMode(SPEAKER,OUTPUT);
    digitalWrite(SPEAKER,LOW);
}

void sound(uint8_t note_index)
{
    for(int i=0;i<100;i++)
    {
        digitalWrite(SPEAKER,HIGH);
        delayMicroseconds(BassTab[note_index]);
        digitalWrite(SPEAKER,LOW);
        delayMicroseconds(BassTab[note_index]);
    }
}

char k='1'; //initializing value
//Callback function to perform action according to subscribed messages
void callback(char* topic, byte* payload, unsigned int length)
{
  k=(char)payload[0];
  if(k=='1')
  {
    sound(1);
    delay(500);
  }
  else
  {
    sound(0);
    delay(500);
  }
}

void setup()
{
    //pin 15 made high to make ports of Wio Link board functional
    pinMode(15,OUTPUT);
    digitalWrite(15,HIGH);
    WiFi.begin(ssid, password);
    Serial.print("Connecting");
    while (WiFi.status() != WL_CONNECTED)
    {
      delay(500);
      Serial.print(".");
    }
    Serial.println();
    //Dsiplay's IP addres of the connected device
    Serial.print("Connected, IP address: ");
    Serial.println(WiFi.localIP());
    client.setServer(mqtt_server, 1883);
    client.setCallback(callback);
    pinInit();
}

void loop()
{
  if (!client.connected())
  {
    reconnect();
  }
  client.loop();
  //Publish value from an MQTT broker such as MQTT.fx client.
  client.subscribe("test/in_topic");
  delay(1000);
}
