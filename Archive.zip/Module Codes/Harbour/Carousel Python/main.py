# Get the Connections from page 10 if this Manual:
# https://www.waveshare.com/w/upload/7/70/1.3inch_LCD_Module_user_manual_en.pdf
# Connect teh screen as per the instructions in the manual
# then execute this code

import spidev as SPI
import ST7789
import time

from PIL import Image,ImageDraw,ImageFont

# Raspberry Pi pin configuration:
RST = 27
DC = 25
BL = 24
bus = 0 
device = 0 

# 240x240 display with hardware SPI:
disp = ST7789.ST7789(SPI.SpiDev(bus, device),RST, DC, BL)

# Initialize library.
disp.Init()

# Clear display.
disp.clear()

# Create multiple copies of this code according to the pictures to be displayed
# Right now only the sample picture is displayed
image = Image.open('pic.jpg')	
disp.ShowImage(image,0,0)
time.sleep(5)