// Sample code for Parallax Emic Text2Speech Module
// taken from: https://www.parallax.com/downloads/emic-2-arduino-example-code

#include <Arduino.h>
#include <SoftwareSerial.h>

#define rxPin   10  // Serial input (connects to Emic 2's SOUT pin)
#define txPin   11  // Serial output (connects to Emic 2's SIN pin)
#define ledPin  13  // Most Arduino boards have an on-board LED on this pin

//Setting up a serial port with the pins defines by us
SoftwareSerial emicSerial =  SoftwareSerial(rxPin, txPin);

void setup()
{
  //pinmodes being defined for our pins
  pinMode(ledPin, OUTPUT);
  pinMode(rxPin, INPUT);
  pinMode(txPin, OUTPUT);
  
  // Defining the baud rate for the SoftwareSerial port for communicating with the module
  emicSerial.begin(9600);
  digitalWrite(ledPin, LOW);
  /*
    When the Emic 2 powers on, it takes about 3 seconds for it to successfully
    initialize. It then sends a ":" character to indicate it's ready to accept
    commands. If the Emic 2 is already initialized, a CR will also cause it
    to send a ":"
  */
  emicSerial.print('\n');             // Send a CR in case the system is already up
  while (emicSerial.read() != ':');   // When the Emic 2 has initialized and is ready, it will send a single ':' character, so wait here until we receive it
  delay(10);                          // Short delay
  emicSerial.flush();                 // Flush the receive buffer
}

void loop()  // Main code, to run repeatedly
{
  // Speak some text (type in any text you want the Emix to output as speech)
  emicSerial.print("Hello. My name is the Emic 2 Text-to-Speech module. I would like to sing you a song.");  // Send the desired string to convert to speech
  emicSerial.print("Hi, This is the test speech from Arduino for communicating with the module");
  emicSerial.print('\n');
  digitalWrite(ledPin, HIGH);         // Turn on LED while Emic is outputting audio
  while (emicSerial.read() != ':');   // Wait here until the Emic 2 responds with a ":" indicating it's ready to accept the next command
  digitalWrite(ledPin, LOW);
    
  delay(500);    // 1/2 second delay

  //Add the commands you want to output
}



